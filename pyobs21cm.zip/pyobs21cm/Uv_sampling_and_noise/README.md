Written by Catherine Watkinson (catherine.watkinson <at> gmail <dot> com).
If you make use of this, please reference this repository and 21cmSENSE literature.

This includes some uv-sampling-noise .h5 files (e.g. ska_central_2019.track_1.0hr_mod_z13.204_nu0.100.h5)
for use out of the box with the main PyObs21cm code.

It also includes uv_to_k_plus_calc_sense.py which can generate new uv-sampling-noise
files for different bandwidths or assumptions about the foregrounds.
The print_cmSENSE_flags() function in the main code can be used to get the
necessary flags for this.

I have also included in /21cmSense_mkarray_files/ the calibration file and
station positions needed to make new array files (such as ska_central_2019.track_1.0hr_blmin0_blmax1610_0.157GHz_arrayfile.npz)
using 21cmSENSE.
