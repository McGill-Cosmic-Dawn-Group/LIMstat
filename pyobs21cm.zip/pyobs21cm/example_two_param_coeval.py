import os, sys
lib_path = os.path.abspath('../')
sys.path.append(lib_path)

import py21cmmc as p21c
import simObs_21cmpy as p21obs
import convs_dists as c_d

'''
    an example script to show how you might utilise this model.
    Here we run 21cmFAST for a certain set of parameters, sample it and add noise
    and then measure the power spectrum from it.
    This is all done by calling the get_coeval_obs_PS modules.

    We then show how to
'''
# ----------------- USER DEFINED PARAMS -------------------
CMSENSE_FLAGS_ONLY = False #If you simply want to know settings to send to 21cmSENSE in order to generate the appropriate UV sampling for your cube
# The returned flags can then be used call uv_to_k_plus_calc_sense.


INST_BASE ='/Users/caw11/_PROGRAMS/PyObs21cm/Uv_sampling_and_noise/'
FG = 'opt' # 'mod', 'opt' or None, latter processes clean simulation. See 21cmSENSE or 21cmMC papers for opt and mod. Roughly speaking: opt = foregrounds removed without residuals; mod = foreground limit assumes moderate spilling of foregrounds beyond theoretical wedge k-limit)
SIM_NOISE = True

# Set the various parameters
UParams = p21c.UserParams(HII_DIM=50, BOX_LEN=150)
CParams = p21c.CosmoParams() # Here we are setting to defaults, could equally pass nothing as function does the same internally
FOptions = p21c.FlagOptions(USE_MASS_DEPENDENT_ZETA=False, USE_TS_FLUCT=False) # Also default, but defining to highlight which parameters control this
AParams = p21c.AstroParams(HII_EFF_FACTOR = 30.0, ION_Tvir_MIN = 4.69897) # Note ION_Tvir_MIN is log so here Tvir = 5 x 10^4

redshifts = [8.04717039344, 9.00285740683, 10.0108973005, 13.2040575177]
# ----------------- END USER DEFINED -------------------

# Define the uv-noise files to be passed (these have been generated using Uv_sampling_and_noise/uv_to_k_plus_calc_sense.py)
if (FG is 'mod'):
    print("Assuming foregrounds in wedge that extends moderately beyond the wedge's theoretical limit")
    Inst_file=['ska512central.track_1.0hr_mod_z8.047_nu0.157.h5']#, 'ska512central.track_1.0hr_mod_z9.003_nu0.142.h5', 'ska512centraltrack_1.0hr_mod_z10.011_nu0.129.h5', 'ska_central_2019.track_1.0hr_mod_z13.204_nu0.100.h5']
elif (FG is 'opt'):
    print("Assuming foregrounds perfectly removed... Ha ha.... Good one!")
    Inst_file=['ska_central_2019.track_1.0hr_opt_z8.047_nu0.157.h5', 'ska_central_2019.track_1.0hr_opt_z9.003_nu0.142.h5', 'ska_central_2019.track_1.0hr_opt_z10.011_nu0.129.h5', 'ska_central_2019.track_1.0hr_opt_z13.204_nu0.100.h5']
else:
    Inst_file=[-1, -1, -1, -1]
# ----------------- END USER DEFINED PARAMS -------------------

if (CMSENSE_FLAGS_ONLY):
    for z_mid in redshifts:
        p21obs.print_cmSENSE_flags(UParams=UParams, CParams=CParams, z=z_mid)
else:
    '''
    This is an example of how to use the code to produce
    the power spectrum from a noisy observed (coeval) simulation.
    This is useful for generating mock datasets for e.g. 21cmMC.
    '''
    if not( FG is None ):
        for i in range(len(Inst_file)) :
            Inst_file[i] = INST_BASE + Inst_file[i]

    # The following produces a single realisation of UV sampled noisy coeval cube and returns the power spectrum
    output = p21obs.PS_from_obs_coeval( AParams=AParams, FOptions=FOptions, UParams=UParams, CParams=CParams, sim_noise=SIM_NOISE, redshifts=redshifts, Inst=Inst_file )

    for i in range(len(output)) :
        print("i = ", i)
        for j in range(output[i].PSbins):
            print((output[i].PS_k[j]),(output[i].PS[j]),(output[i].PS_error[j]))
