from cosmocalc_py3 import cosmocalc
import numpy as np
from scipy import signal
from numpy.fft import fftn, ifftn, fftfreq, rfftfreq

'''
Contains common conversions, signal processing and cosmological distance calculations
common to the main modules
'''

# CONSTANTS DO NOT ALTER!
TOCM_NU0 = 1420.40575177 # rest frame 21cm frequency (MHz)
TOCM_LAM0 = 2.998e8/(TOCM_NU0*1.0e6) #rest frame 21cm wavelength (m)
SPEEDOFLIGHT_CGS=2.99792458e10 # Speed of light in cgs
H0_CMSMPC=1.0e7 # H0 in units of cm/s/Mpc

def fft_data(data, L=None, axes=None, ret_k_grid=False):
	'''
		A basic forward fft adapted from powerbox.dft (Steven Murray)

		Args:
		[data] : Array with arbitrary dimensions defining the field to be transformed
		[L] (optional) : Array or scalar defining dimension (if scalar code assumes data is cubic; default leaves fft unnormalised)
		[axes] (optional) : sequence of ints defining axes to take the transform over. The default is to perform transform over all axes.
		[ret_k_grid] (optional) - If True returns the entire grid of k magnitudes. Default is False.

		Returns: fft_data, freq, k_grid
		[fft_data] - DFT of [data] (normalised to be consistent with continuous and perhaps for data size if L passed)
		[ks] - list of arrays containing k's in each direction (one for each dimension)
		[k_grid] - returned when ret_k_grid = True specifies magnitude of k at each point in the FFT grid
	'''
	# Use standard normalisation for FFT
	a=0
	b=2.0*np.pi

	if axes is None:
		axes = list(range(len(data.shape))) # extracts axes array from data if not passed

	N = np.array([data.shape[axis] for axis in axes]) # defines N - number pixels per side

	# Set L = N if not passed otherwise make sure it is an array for each dimension if passed as a scalar (assumes data cubic)
	if L is None:
		L = N+0.0
	elif L is not None:    # give precedence to L
		if np.isscalar(L):
			L = L*np.ones(len(axes))

	# Extract the various volumes needed for normalisation
	V = float(np.product(L))    # Volume of box
	Vx = V/np.product(N) # Volume of cell

	# Perform the Fourier transform (note I removed fftshift from the original so negative k in data[-N/2:-1])
	ft = Vx*fftn(data, axes=axes)*np.sqrt(np.abs(b)/(2*np.pi) ** (1 - a)) ** len(axes)
	print("in fft_data, datatype and shape returned by fftn = ", type(ft), ft.shape)
	dx = np.array( [float(l)/float(n) for l, n in zip(L, N)] ) #dx for each axes (i.e. pixel size in real space)
	#print('dx = ', dx)
	ks = np.array( [fftfreq(n, d=d) for n, d in zip(N, dx)] )*(2*np.pi)  # returns the k's that correspond to each axis

	# Now return the goods
	if not ret_k_grid:
		return ft, ks
	else:
		grid = ks[0] ** 2
		for i in range(len(axes) - 1):
			grid = np.add.outer(grid, ks[i+1] ** 2)

		return ft, ks, np.sqrt(grid)

def ifft_data(fft_data, L=None, axes=None):
	'''
		Returns [ift] the inverse DFT of [fft_data] - see fft_data() for description of args and output
		Also returns:
		[xs] - list of arrays containing k's in each direction (one for each dimension)
	'''

	# Use standard normalisation for FFT
	a=0
	b=2.0*np.pi

	if axes is None:
		axes = list(range(len(fft_data.shape)))

	N = np.array([fft_data.shape[axis] for axis in axes])

	# Removed the option to pass Lk as we did for fft_data
	if L is None:
		Lk = 1
	elif L is not None:
		if np.isscalar(L):
			L = np.array([L]*len(axes))
		dx = (L+0.0)/(N+0.0)
		print('dx (in ift) = ', dx)
		Lk = 2.0*np.pi/(dx*b) #cw dx*b -> dx
	elif np.isscalar(Lk):
		Lk = [Lk]*len(axes)

	Lk = np.array(Lk)

	V = np.product(Lk)
	dk = np.array([float(lk)/float(n) for lk, n in zip(Lk, N)])
	print("dk =", dk*b, "should be = ", 2.0*np.pi/L)
	ift = V*ifftn(fft_data, axes=axes)*np.sqrt(np.abs(b)/(2*np.pi) ** (1 + a)) ** len(axes)

	# The real-space co-ordinate grid in each dimension
	xs = np.array( [rfftfreq(n, d=d) for n, d in zip(N, dk)] )*(2*np.pi/b) #*(2*np.pi/b)

	return ift, xs

def nd_windowfunc(data, beta):
	"""
	Performs an in-place kaiser windowing on N-dimensional spatial-domain data.
	This is done to mitigate boundary effects in the FFT.

	Parameters
	----------
	[data] - ndarray
		   Input data to be windowed, modified in place.
	[beta] : shape parameter for window 0 is rectangle
	"""
	for axis, axis_size in enumerate(data.shape):
		# set up shape for numpy broadcasting
		filter_shape = [1, ] * data.ndim
		filter_shape[axis] = axis_size
		#window = np.kaiser(axis_size, beta).reshape(filter_shape)
		window = signal.tukey(axis_size, beta).reshape(filter_shape)
		# scale the window intensities to maintain image intensity with repeat application of same WF
		window=window**(1.0/data.ndim)
		data *= window
	#return data

def z_from_nu(nu):
	# Returns z from nu (MHz)
	return ( TOCM_NU0/nu - 1.0 )

def nu_from_z(z):
	# returns observed frequency (MHz) for 21cm line at a given redshift z
	return ( TOCM_NU0/(1.0+z) )

def z_from_lambda(lam_obs):
	# Returns z given the observed wavelength of 21cm line, lambda (m)
	return lam_obs/TOCM_LAM0 - 1.0

def lamda_from_z(z):
	# returns observed wavelength (m) for 21cm line at a given redshift z
	return TOCM_LAM0*(1.0+z)

def delnu_from_cMpc(los_cMpc, z_mid, omega_m=0.3075, hlittle=0.6774):
	'''
		Returns the bandwidth in MHz corresponding to a los distance in cMpc
		(ref: Morales & Hewitt 2004 http://adsabs.harvard.edu/abs/2004ApJ...615....7M)
		INPUTS:
		los_cMpc - los distance
		z_low - redshift at nearest side/lowest redshift side of the distance considered
		CParams - list of cosmology parameters, see README.md for details of how to define.
	'''
	#print(CParams.OMm, CParams.hlittle) cw checked

	# 21cmMC construct currently only accepts flat universe cosmology, this will need adapting if this changes.
	# Calculate the Hubble parameter E(z)*H0/c
	#print("In delnu_from_cMpc -> args los_cMpc, z_mid, omM, h = ", los_cMpc, z_mid, omega_m, hlittle)
	Ez2 = omega_m*np.power(1.+z_mid,3.)
	Ez2 += (1.0 - omega_m)
	Ez = np.sqrt(Ez2)
	#print("In delnu_from_cMpc -> Ez = ", Ez)
	cH = SPEEDOFLIGHT_CGS/hlittle/H0_CMSMPC;
	Ez /= cH
	#print("In delnu_from_cMpc -> Ez/cH = ", Ez)

	delnu = TOCM_NU0*Ez*los_cMpc
	delnu /= (1+z_mid)**2

	return delnu

def Dm_cc(z=None, omega_m=0.3075, hlittle=0.6774):
	'''
		Returns the cosmocalc estimation of comoving distance to z
	'''
	if (z is None):
		print("conv_dists.Dm_cc -> z must be passed. Usage: Dm_cc(z, omega_m, hlittle)")
	cosmocalc_dict = cosmocalc(z, 100.0*hlittle, omega_m, 1.0-omega_m)
	return cosmocalc_dict['DCMR_Mpc']


def klos_from_eta(eta_cMHz, z_mid, omega_m=0.3075, hlittle=0.6774):
	'''
	Returns k_los = 2pi/(\delta x) in cMpc^{-1} given \eta = 2pi/(\delta nu)

	Given the reciprocal relation to scale x and frequency nu,
	this is identical to delnu_from_cMpc() conversion multiplied by 2pi
	(Ref: Vedantham, Shankar, Subrahmanyan 2012 https://iopscience.iop.org/article/10.1088/0004-637X/745/2/176/pdf)
	'''

	return ( 2.0*np.pi*delnu_from_cMpc(eta_cMHz, z_mid, omega_m, hlittle) )

def kperp_from_uv(u_or_v, z, omega_m=0.3075, hlittle=0.6774, Dm=None):
	'''
	This returns the comoving k on the sky given a u or v component.
	Dm is the comoving distance, this can be precalculated and passed to increase speed on multiple calls
	'''
	if (Dm is None):
		Dm = Dm_cc(z, omega_m, hlittle)

	return (2*np.pi/Dm)*u_or_v
