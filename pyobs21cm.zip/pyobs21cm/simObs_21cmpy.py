"""
	This module deals with simulating the 21cmFAST power spectrum and if required
	approximates the observational noise.

	MODULE MENU:
	get_coeval_obs_PS() - basic coeval cube with option to apply uv sampling and noise

"""

import os, sys
import numpy as np
import numpy.random as random
import math
from scipy import interpolate
from decimal import *
import h5py
import astropy.io.fits as pyfits
from subprocess import call
from pathlib import Path
from scipy import interpolate
import warnings

from numpy.fft import fftn, ifftn, fftfreq, rfftfreq

import convs_dists as conv

from py21cmfast import plotting
import py21cmfast as p21c

np.seterr(invalid="ignore", divide="ignore")

# Setup ctypes
import ctypes
from ctypes import cdll
from ctypes import c_float, c_int, c_uint, c_double, c_char_p

# Location of the .so for the power spectrum module
SharedLibraryLocation = "./pyobs21cm/Compute_21cmPS.so"

Lib_21cmPS = cdll.LoadLibrary(SharedLibraryLocation)
Function_21cmPS = Lib_21cmPS.Compute_21cmPS

# Data structure for the returned data from the C code
class Point(ctypes.Structure):
    _fields_ = [
        ("PSbins", c_int),
        ("PS_k", ctypes.POINTER(c_float)),
        ("PS", ctypes.POINTER(c_float)),
        ("PS_error", ctypes.POINTER(c_float)),
    ]


Function_21cmPS.restype = Point
Function_21cmPS.argtypes = [
    c_int,
    c_int,
    c_int,
    c_int,
    c_float,
    ctypes.POINTER(c_float),
]

DEBUG = 1  # 0 Supresses unnecessary print outs, 1 = debug mode, print everything out.

""" ------------------------------------------------------------------------------------------------------------

									 'HELPER' FUNCTIONS

		  USED BY MAIN 'ACTION' FUNCTIONS, USER SHOULD NOT NEED TO CALL THESE DIRECTLY

 ------------------------------------------------------------------------------------------------------------ """


def find_closest_1Dindex(k=None, kf=None):
    #
    cont_bin = (k + 0.0) / (kf + 0.0)
    #
    floor_and_ceil = [math.floor(cont_bin), math.ceil(cont_bin)]
    ind = floor_and_ceil[(np.abs(floor_and_ceil - cont_bin)).argmin()]
    """if ( abs(k-0.58450692) <= 0.00001 ):
		print("find_closest_1Dindex() ->  k = ", k, "kf = ", kf)
		print("find_closest_1Dindex() ->  continuous bin = ", cont_bin)
		print("find_closest_1Dindex() ->  floor_and_ceil = ", floor_and_ceil)
		print("find_closest_1Dindex() ->  index assigned to sample = ", ind)"""

    return ind


def load_ks_Pnoise(Filepath=None):
    if Filepath is None:
        raise ValueError(
            "In load_ks_Pnoise() -> Problem: I can't very well open fresh air..."
            "\n USAGE: load_ks_Pnoise(Filepath)"
        )
    else:
        print("In load_ks_Pnoise() -> loading data from h5 file")
        # Open and load kx, ky, kz and Pnoise
        with h5py.File(Filepath, "r") as hf:
            kx = hf["kx_cMpc"][:]
            ky = hf["ky_cMpc"][:]
            kz = hf["klos_cMpc"][:]
            Pnoise = hf["Pnoise"][:]
    if DEBUG == 1:
        print("Length of imported k and Pnoise arrays = ", len(kx))
    return kx, ky, kz, Pnoise


def k_pls(z=None, Dim=None, Len=None, omega_m=0.3075, hlittle=0.6774):
    """
    Returns the k_pls associated with the freq Len and Dim of the frequency axis
    z is the middle redshift associated with the centre of the freq range
    """
    if (z is None) or (Dim is None) or (Len is None) or (z is None):
        raise ValueError("k_pls-> You need to pass at least z, Dim, and Len arguments")

    # Multiply by this to convert a bandwidth in MHz to a line of sight distance in Mpc/h at redshift z
    """[h^-1 Mpc]/MHz, from Furlanetto et al. (2006) """

    # dL_df = (1.7 / 0.1) * ((1+z) / 10.)**.5 * (omega_m/0.15)**-0.5 #* 1e3 #cw CONVERTED TO /MHZ

    # Multiply by this to convert eta (FT of freq.; in 1/GHz) to line of sight k mode in 1/Mpc at redshift z
    """2pi * [h Mpc^-1] / [MHz^-1]"""
    # dk_deta = 2*np.pi*hlittle / dL_df
    B = conv.delnu_from_cMpc(Len, z, omega_m, hlittle)  # MHZ
    # cw replaced 21cmSENSE approx conversion
    # eta_los = dk_deta*np.fft.fftfreq(Dim, B/Dim)
    eta_los = np.fft.fftfreq(Dim, B / Dim)
    kpls = np.zeros(len(eta_los))
    for i in range(len(eta_los)):
        kpls[i] = conv.klos_from_eta(eta_los[i], z, omega_m, hlittle)

    return kpls  # eta_los


def random_sample_noise(Pnoise):
    """
    This generates a 3D fft_coeval with random sampling of noise assuming mean zero and sigma = sqrt(Pnoise)
    Pnoise.real = Power spectrum of instrumental noise
    Pnoise.complex = Power spectrum of sample variance (equivalent to the power spec of the Tb signal on a given scale)
    """
    random.seed()  # This uses the time as a seed, so will produce a different pattern of numbers each time
    # mean  = np.zeros(noise_1sigma.shape)
    # print("random_sample_noise -> ", noise_1sigma.shape)
    noise_1sig_samp = np.zeros(Pnoise.shape, dtype=complex)
    for ind, value in np.ndenumerate(Pnoise):
        # print("ind = ", ind, ind[0], ind[1], ind[2], "value", value)

        if (ind[2] > 0) and (
            ind[2] < Pnoise.shape[2] / 2.0
        ):  # add noise for pixels in positive half of z-axis and conjugate for -z terms as per the hermitian reality condition
            # DEVEL_SAMPVAR
            # Make sample of noise due to instrument
            noise_1sig_samp[ind[0], ind[1], ind[2]] = complex(
                random.normal(0.0, np.sqrt(value.real) + np.sqrt(value.imag)),
                random.normal(0.0, np.sqrt(value.real) + np.sqrt(value.imag)),
            )
            noise_1sig_samp[ind[0], ind[1], Pnoise.shape[2] - ind[2]] = np.conj(
                noise_1sig_samp[ind[0], ind[1], ind[2]]
            )

        # print( "random_sample_noise -> ", noise_1sig_samp[ind], np.sqrt(value.real) )
    if DEBUG == 1:
        print(
            "In random_sample_noise -> mean, variance = ",
            np.mean(noise_1sig_samp),
            np.var(noise_1sig_samp),
        )

    return noise_1sig_samp


def generate_uv_mask(
    kx=None,
    ky=None,
    kz=None,
    Pnoise=None,
    Psv=None,
    Dim=None,
    Len=None,
    redshft=None,
    omega_m=0.3075,
    hlittle=0.6774,
):
    """
    This generates a 1 if the pixel is sampled by the passed kx, ky, kz and a 0 if not
    INPUTS
    Required:
    [kx], [ky], [kz] (cMpc^{-1}) previously loaded from uv sampling/noise file and
    Optional:
    [sim_fft_data] - FFTed simulation, [Pnoise] - sim_fft_data.shape array,
    and [Psv] - interpolation fn of sample variance power (which is the PS of cosmo Tb signal) (see outputs for how these control behaviour)

    OUTPUTS
    [mask_fft_coeval] which is a coeval (real but indexed as fft box)
    with zeroes where no corresponding uv samples, otherwise:

    [Pnoise is None] only - Total number of uv samples in each sampled pixel
    not[Pnoise is None] - The INSTRUMENTAL NOISe power in each sampled pixel for use with random_sample_noise (**stored in real part of mask)
    not[Psv is None] - contribution to noise from sample variance included (stored in complex part of mask)
    """
    if (
        (kx is None)
        or (ky is None)
        or (kz is None)
        or (Dim is None)
        or (Len is None)
        or (redshft is None)
    ):
        raise ValueError(
            "In generate_coeval_uv_mask() -> Come on dude, "
            "give me something to work with! \n USAGE: "
            "generate_uv_mask(kx, ky, kz, Dim, Len, z, omega_m, hlittle)"
        )

    # Calculate fundamental k-pixel size on the sky i.e. k_perp
    kf = 2.0 * np.pi / (Len + 0.0)

    # Work out the k_eta modes in the frequency direction (i.e los/parallel) to calculate fundamental k_eta pixel size
    kpls = k_pls(z=redshft, Dim=Dim, Len=Len, omega_m=omega_m, hlittle=hlittle)
    kf_eta = kpls[1] - kpls[0]
    print(
        "In generate_coeval_uv_mask() -> Fundamental k-pixel size for freq axis is ",
        kf_eta,
        "\n kpls = ",
        kf_eta,
    )

    if not ((Dim % 2) == 0):  # To allow for fourier padding
        print(
            "In generate_coeval_uv_mask() -> padding mask as array dimension is not even"
        )
        Dim += 1

    mask_fft_coeval = np.zeros((Dim, Dim, Dim), dtype=complex)
    samp_ct = np.zeros((Dim, Dim, Dim))
    # print(mask_fft_coeval.shape)
    for i, k_x in enumerate(kx):
        ind_x = find_closest_1Dindex(k=k_x, kf=kf)
        ind_y = find_closest_1Dindex(k=ky[i], kf=kf)
        ind_z = find_closest_1Dindex(k=kz[i], kf=kf)

        if (
            (np.abs(ind_x) < Dim / 2.0)
            and ((np.abs(ind_y) < Dim / 2.0))
            and (np.abs(ind_z) < Dim / 2.0)
            and not ((ind_x == 0) and (ind_y == 0) and (ind_z == 0))
        ):  # doesn't sample 0th k mode.

            if (
                Pnoise is None
            ):  #  Generating a basic uv sampling mask as no noise has been passed
                mask_fft_coeval[ind_x, ind_y, ind_z] += 1.0

            else:  # Generating a noisey uv sampling mask
                # calculate the kmag for this sample (for sample variance)
                kmag = np.sqrt(k_x * k_x + ky[i] * ky[i] + kz[i] * kz[i])
                if not (Psv is None):
                    # print("generate_coeval_uv_mask() -> ", kmag, Psv(kmag) )
                    mask_fft_coeval[ind_x, ind_y, ind_z] += complex(
                        Pnoise[i], Psv(kmag)
                    )
                else:
                    mask_fft_coeval[ind_x, ind_y, ind_z] += complex(Pnoise[i], 0.0)
                samp_ct[ind_x, ind_y, ind_z] += 1.0
                # print("generate_coeval_uv_mask() -> ", samp_ct[ind_x, ind_y, ind_z], mask_fft_coeval[ind_x, ind_y, ind_z] )

    if Pnoise is None:  # Just return the mask with number of uv samples per pixel
        return mask_fft_coeval

    else:  # Take average of noise in pixels that have been sampled several times
        for ind, ct in np.ndenumerate(mask_fft_coeval):
            if samp_ct[ind] > 0.0:
                mask_fft_coeval[ind] /= samp_ct[
                    ind
                ]  # cw.real # I choose to not divide by N^2 because signal within pixel can't be assumed to be coherent
        return mask_fft_coeval  # / samp_ct.real )


""" ------------------------------------------------------------------------------------------------------------

										  'ACTION' FUNCTIONS

				USE DIRECTLY THESE TO GENERATE UV-SAMPLING MASKS (WITH OR WTHOUT NOISE)
				AND TO CREATE RANDOM REALISATIONS OF OBSERVATION NOISE + UV-SAMPLE A PASSED SIMULATION

 ------------------------------------------------------------------------------------------------------------ """


def print_cmSENSE_flags(UParams=None, CParams=None, z=None):
    """
    Given as set of 21mMC user-settings dictionaries, suggests appropriate flags for use with uv_to_k_plus_calc_sense.py
    which can be used with the array files generated by 21cmSENSE mk_array_file.
    (this provides kx, ky, kz, Pnoise files for use in the rest of this package)
    """
    if (UParams is None) or (CParams is None) or (z is None):
        print(
            "In print_cmSENSE_flags() -> Give a dog a bone! \n Usage reminder :\n print_cmSENSE_flags(UParams, CParams, z)"
        )
        return -1
    print(
        "In print_cmSENSE_flags() -> The following provides the bandwidth and nchan flags to pass to uv_to_k_plus_calc_sense.py to generate a uv-sampling/noise file for current parameter settings"
    )
    print("z = ", z)
    print(
        "--nchan ",
        UParams.HII_DIM,
        " --bwidth ",
        conv.delnu_from_cMpc(UParams.BOX_LEN, z, CParams.OMm, CParams.hlittle) / 1000.0,
        " --hlittle ",
        CParams.hlittle,
        " --omega_m ",
        CParams.OMm,
    )
    return


def get_obs_fft_coeval(
    kx=None,
    ky=None,
    kz=None,
    Pnoise=None,
    Psv=None,
    Dim=None,
    Len=None,
    uv_mask=None,
    sim_noise=False,
    sim_fft_data=None,
    redshft=None,
    omega_m=0.3075,
    hlittle=0.6774,
):
    """
    Use this to generate a uv-sampling fft mask (with or without noise 1-sigma in sampled pixel),
    or sample and/or add noise to a simulation ffted coeval

    INPUTS
    Given [kx], [ky], [kz] (cMpc^{-1}) previously loaded from uv sampling/noise file
    [sim_fft_data], [uv_mask] and [Pnoise] optionals (see outputs for how these control behaviour)

    OUTPUTS
    [obs_fft_coeval] which is:

    dT-only uv-sampled fft coeval - [not(sim_fft_data is None)] and [Pnoise=None]

    noise-only uv-sampled fft coeval - [sim_fft_data is None] and [not(Pnoise is None)]

    dT+noise uv-sampled fft coeval - [not(sim_fft_data is None)] and [not(Pnoise is None)]

    sampling mask fft coeval - [uv_mask is None] (0 where not sampled and Num_samps elsewhere if [sim_noise=False] and noise_1sigma if [sim_noise=True])

    When trying to generate multiple noisey observations of the same simulation.
    Call this once with [uv_mask=None] then pass the returned noise mask for all future calls.

    """

    if (kx is None) or (ky is None) or (kz is None) or (redshft is None):
        raise ValueError(
            "In get_obs_fft_coeval() -> You have failed to pass kx, ky and kz arrays.\n !!!!! ABORTING perform_uv_sampling() without performing sampling."
        )
    if not (len(kx) == len(ky) == len(kz)):
        raise ValueError(
            "In get_obs_fft_coeval() -> There is something fishy here, the lengths of kx (",
            str(len(kx)),
            "), ky (",
            str(len(ky)),
            "), and kz (",
            str(len(kz)),
            " are not the same. \n !!!!! ABORTING perform_uv_sampling() without performing sampling.",
        )
    elif not (Pnoise is None):
        if not (len(kz) == len(Pnoise)):
            raise ValueError(
                "In get_obs_fft_coeval() -> There is something fishy here, the lengths of kx (",
                str(len(kx)),
                "), ky (",
                str(len(ky)),
                "), kz (",
                str(len(kz)),
                ") and Pnoise (",
                str(len(Pnoise)),
                ") are not the same. \n !!!!! ABORTING perform_uv_sampling() without performing sampling.",
            )

    # If no uv mask is passed just return a sampling mask (0 if a uv pixel, 1 otherwise) designed for use with numpy.ma
    if uv_mask is None:
        if DEBUG == 1:
            print("uv_mask average in get_obs_fft_coeval() = ", uv_mask)
        print(
            "In get_obs_fft_coeval() -> Generating a coeval noise mask. P_noise where sampled, zero otherwise."
        )
        obs_coeval = generate_uv_mask(
            kx=kx,
            ky=ky,
            kz=kz,
            Pnoise=Pnoise,
            Psv=Psv,
            Dim=Dim,
            Len=Len,
            redshft=redshft,
            omega_m=omega_m,
            hlittle=hlittle,
        )
        return obs_coeval

    # If only a simulated fft coeval is passed, just apply uv sampling and return
    elif (sim_noise is False) and not (sim_fft_data is None):
        print(
            "In get_obs_fft_coeval() -> Generating a observed dT coeval (no noise) as only sim_fft_data has been passed"
        )
        # return uv_mask
        # print("number of pixels that meet the masking requirement: ", len(sim_fft_data[ (uv_mask==0) ]))
        sim_fft_data[(uv_mask == 0j)] = 0j

    # If sim_Noise is True then applying sampling and simulate the noise
    elif (sim_noise is True) and (sim_fft_data is not None):
        print(
            "In get_obs_fft_coeval() -> Applying UV sampling and adding random noise to the simulation passed"
        )
        sim_fft_data[(uv_mask == 0j)] = 0j
        print(np.sum(uv_mask == 0j) / sim_fft_data.size)
        noise_sampling = random_sample_noise(uv_mask)
        for ind, value in np.ndenumerate(noise_sampling):
            # sim_fft_data[ (uv_mask>0.0) ] += noise_sampling[ uv_mask>0.0 ]
            # print("ind", ind, "simulation dT before noise = ", sim_fft_data[ ind ])
            sim_fft_data[ind] += noise_sampling[ind]
            # print("simulation dT after add noise (N=", noise_sampling[ ind ], ") = ", sim_fft_data[ ind ])
        print(np.mean(sim_fft_data))
    else:  # No simulation passed, so just make a noisy box
        print("In get_obs_fft_coeval() -> no simulation passed, returning noisy box")
        noise_sampling = random_sample_noise(uv_mask)
        if DEBUG == 1:
            print(
                "In get_obs_fft_coeval() -> noise sampling",
                np.fft.fftshift(noise_sampling)[20, 20, 20],
                np.fft.fftshift(noise_sampling)[30, 30, 30],
            )
            hdu = pyfits.PrimaryHDU(np.real(np.fft.fftshift(noise_sampling)))
            hdulist = pyfits.HDUList([hdu])
            filename = "noise_fft_z" + str(redshft) + ".fits"
            call(["rm", filename])
            hdulist.writeto(filename)
            hdulist.close()
        return noise_sampling

    return sim_fft_data


def get_obs_coeval(
    Filepath=None,
    z=None,
    Dim=None,
    Len=None,
    sim_noise=False,
    Psv=None,
    sim_coeval=None,
    omega_m=0.3075,
    hlittle=0.6774,
):
    """
    This generates a real-space noisy box using the uv-sampling and noise power spec
    (see README.md for the required format of uv-sampling/noise file).
    It does not allow for line-of-sight evolution in the uv sampling and noise so only to be applied over small bandwidth.

    The simulation is also assumed to be coeval in cMpc^3.
    The workflow in this can be used as a template for generating multiple noise realisations.

    ARGS:
    [Filepath] path to uv-sampling/noise file
    [Dim] number pixels on the box side
    [Len] Size of coeval box side in cMpc
    [sim_noise] true it simulates noise
    [sim_coeval] FFTed simulation dT coeval

    RETURNS:
    [noise_box] which is an observed [sim_coeval]+noise observation coeval...
                            or without noise if [sim_noise=False]...
                            or just the fft mask if [sim_noise=False] and [sim_coeval is None]..
    """
    if (Filepath is None) or (Filepath == -1):
        raise ValueError(
            "In get_obs_coeval() -> You have not passed a filepath for uv-sampling/noise. !!!!! ABORTING get_obs_coeval() without simulating noise."
        )
    elif z is None:
        raise ValueError(
            "In get_obs_coeval() -> You have not passed a redshift, noise cannot be calculated. !!!!! ABORTING get_obs_coeval() without simulating noise."
        )
    elif (Dim is None) or (Len is None):
        raise ValueError(
            "In get_obs_coeval() -> You have not passed the dimension and/or lenth for the box, noise cannot be calculated. !!!!! ABORTING get_obs_coeval() without simulating noise."
        )
    else:
        pixel_size = Len / (Dim + 0.0)
        # print("get_obs_coeval() -> pixel size = ", pixel_size)

        kx, ky, kz, Pnoise = load_ks_Pnoise(Filepath=Filepath)

        # First we generate a noise mask, this is all that happens if no simulation has been passed, this has P_noise in pixels which have been samples
        # Check if we already have a mask on disk for the corresponding noise file and use instead of doubling effort
        mask_fname = Filepath[0:-3] + "_maskfile.h5"
        mask_fpath = Path(mask_fname)
        if mask_fpath.exists():
            print(
                "In get_obs_coeval() -> ",
                mask_fname,
                " mask_file exists, no need to call gen_mask via get_obs_fft_coeval",
            )
            with h5py.File(mask_fname, "r") as hf:
                mask_for_ffted_coeval = hf["mask_sampling_box"][:]
        else:
            print(
                "In get_obs_coeval() -> ",
                mask_fname,
                " mask_file does not exist, so generating from passed uv_noise_file from scratch",
            )
            mask_for_ffted_coeval = get_obs_fft_coeval(
                kx=kx,
                ky=ky,
                kz=kz,
                Pnoise=Pnoise,
                Psv=Psv,
                Dim=Dim,
                Len=Len,
                redshft=z,
                omega_m=omega_m,
                hlittle=hlittle,
                uv_mask=None,
            )
            with h5py.File(mask_fname, "w") as hf:
                hf.create_dataset("mask_sampling_box", data=mask_for_ffted_coeval)

        if sim_coeval is not None:  # a dT-sim coeval has been passed
            print("In get_obs_coeval() -> 21CMFAST simulation has been passed")
            # cw sim_fft_coeval, ks_sampling = conv.fft_data(sim_coeval, L=Len)
            sim_fft_coeval = np.fft.fftn(sim_coeval, axes=(0, 1, 2))
            if DEBUG == 1:
                print(
                    "In get_obs_coeval() -> Data shape after FFT = ",
                    sim_fft_coeval.shape,
                )
            if sim_noise is False:
                # then please don't simulate noise, simply apply uv sampling
                print(
                    "In get_obs_coeval() -> Applying uv-sampling, but not adding noise"
                )
                obs_coeval_fft = get_obs_fft_coeval(
                    kx=kx,
                    ky=ky,
                    kz=kz,
                    Dim=Dim,
                    Len=Len,
                    uv_mask=mask_for_ffted_coeval,
                    sim_fft_data=sim_fft_coeval,
                    redshft=z,
                    omega_m=omega_m,
                    hlittle=hlittle,
                )
            else:
                # observed dT+noise coeval
                print("In get_obs_coeval() -> Applying uv-sampling and adding noise")
                obs_coeval_fft = get_obs_fft_coeval(
                    kx=kx,
                    ky=ky,
                    kz=kz,
                    Dim=Dim,
                    Len=Len,
                    uv_mask=mask_for_ffted_coeval,
                    sim_noise=True,
                    sim_fft_data=sim_fft_coeval,
                    redshft=z,
                    omega_m=omega_m,
                    hlittle=hlittle,
                )
            print("In get_obs_coeval() -> FFTing simulation c2r")
            # cw obs_coeval, x_samp = conv.ifft_data( obs_coeval_fft, L=Len )
            obs_coeval = np.fft.irfftn(
                obs_coeval_fft, axes=(0, 1, 2), s=obs_coeval_fft.shape
            )
            # cw if not( x_samp[1][1] == Len/(Dim+0.0) ) :
            # cw print("get_obs_coeval() -> Oh my, it seems like there is something wrong with the FFT scalings. x_sampl = ", x_samp[1][1], "should be Len/Dim = ", Len/(Dim+0.0))

        # FFT c2r and make absolute (as we are always dealing with real data here)
        else:  # no simulation was passed so either return the mask or a noisy box
            if sim_noise is False:  # noise-only coeval (basically the noisy mask)
                print("In get_obs_coeval() -> no simulation has been passed...")
                print("get_obs_coeval() -> Not FFTing c2r as just returning the mask")
                return mask_for_ffted_coeval
            else:
                print("In get_obs_coeval() -> generating a noisy box")
                obs_coeval_fft = get_obs_fft_coeval(
                    kx=kx,
                    ky=ky,
                    kz=kz,
                    Dim=Dim,
                    Len=Len,
                    uv_mask=mask_for_ffted_coeval,
                    sim_noise=True,
                    sim_fft_data=None,
                    redshft=z,
                    omega_m=omega_m,
                    hlittle=hlittle,
                )

                print(
                    "In get_obs_coeval() -> noise sampling",
                    np.fft.fftshift(obs_coeval_fft)[20, 20, 20],
                    np.fft.fftshift(obs_coeval_fft)[30, 30, 30],
                )
                print("In get_obs_coeval() -> FFTing noise realisation c2r")

                # cw obs_coeval, x_samp = conv.ifft_data( obs_coeval_fft, L=Len )
                obs_coeval = np.fft.irfftn(
                    obs_coeval_fft, axes=(0, 1, 2), s=obs_coeval_fft.shape
                )
                if DEBUG == 1:
                    print(obs_coeval.shape, obs_coeval.dtype, np.mean(obs_coeval))

        # return the real part of the box
        print(obs_coeval.mean(), np.var(obs_coeval))
        return obs_coeval.real.astype(
            np.float32
        )  # because we are working with real space data


""" ------------------------------------------------------------------------------------------------------------

							'WRAPPER' FUNCTIONS
			TO CALCULATE STATISTICS FROM MOCK OBSERVED SIMULATIONS

 ------------------------------------------------------------------------------------------------------------ """


def PS_from_obs_coeval(
    AParams=-1,
    FOptions=-1,
    UParams=-1,
    CParams=-1,
    redshifts=[8.0, 9.0, 10.0],
    sim_noise=True,
    Inst=[-1, -1, -1],
):

    """
    This runs 21cmFAST and if required approximates observation by applying
    UV sampling and adds instrumental noise.
    See section 1 of example_two_param_coeval.py to see how to call.

    ARGS...
    [*Params/Options] controls the behaviour of the simulation see README.md or 21cmMC documentations for details
    [redshifts] is a list of the redshifts you wish to simulate
    [sim_noise] if False, just applies uv sampling, otherwise simulates instrumental noise.
    [Inst] is a list of length matching redshifts containing -1's or
    filepath for corresponding files containing uv sampling and noise
    (see README.md for the required format of uv-sampling/noise file)

    OUTPUT...
    a list of length(redshifts) each entry containing: [k [cMpc^{-1}], PS [cMpc^{-3} mK^2] and PSerr [cMpc^{-3} mK^2]
    """
    # ----------------------------------------------------------------------
    # Initialise 21cmMC dictionaries and power spec default flags
    LightConeFlag = 0
    DIMENSIONAL_T_POWER_SPEC = 1  # mK^2

    # Controls the default behaviour if the user doesn't pass any parameters
    # Can params as args having previously defined e.g. UParams = p21c.UserParams(HII_DIM=50, BOX_LEN=150)
    if AParams == -1:
        print(
            "In get_coeval_obs_PS() -> setting AParams to default: ",
            p21c.AstroParams._defaults_,
        )
        AParams = p21c.AstroParams()
    if FOptions == -1:
        print(
            "In get_coeval_obs_PS() -> setting FlagOptions to default: ",
            p21c.FlagOptions._defaults_,
        )
        FOptions = p21c.FlagOptions()
    if UParams == -1:
        print(
            "In get_coeval_obs_PS() -> setting UserParams to default: ",
            p21c.UserParams._defaults_,
        )
        UParams = p21c.UserParams()
    if CParams == -1:
        print(
            "In get_coeval_obs_PS() -> setting CosmoParams to default: ",
            p21c.CosmoParams._defaults_,
        )
        CParams = p21c.CosmoParams()
    # ----------------------------------------------------------------------

    # ----------------------------------------------------------------------
    # Run 21cmMC to get the cosmological 21cm signal as a coevolving cube (in cMpc)
    coevals = p21c.run_coeval(
        redshift=list(redshifts),
        user_params=UParams,
        cosmo_params=CParams,
        astro_params=AParams,
    )
    # ----------------------------------------------------------------------

    # ----------------------------------------------------------------------
    # Initialise simulation-dependent variables for power spectrum code
    # Define the size of the data cube to be passed to C for constructing the 21cm power spectrum
    size = UParams.HII_DIM * UParams.HII_DIM * UParams.HII_DIM

    # Convert the data to C type data
    c_float_p = ctypes.POINTER(ctypes.c_float)
    # ----------------------------------------------------------------------

    # ----------------------------------------------------------------------
    # Not loop over the redshifts we have 21cmMC simulations for, simulate observation and measure PS
    dTobs = []
    output = []
    for i in range(len(redshifts)):
        # ----------------------------------------------------------------------
        # First get the cosmological power spectrum that we may use for sample variance error
        dTobs = coevals[i].brightness_temp.ctypes.data_as(c_float_p)
        obs_sim = 0
        Delta_cs = Function_21cmPS(
            LightConeFlag,
            obs_sim,
            DIMENSIONAL_T_POWER_SPEC,
            UParams.HII_DIM,
            UParams.BOX_LEN,
            dTobs,
        )
        # Convert from default Function_21cmPS output of Delta_sv(k) to P_sv(k)
        for j in range(Delta_cs.PSbins):
            # print("get_coeval_obs_PS() -> ", Delta_cs.PS[j])
            Delta_cs.PS[j] *= 2.0 * np.pi**2 / Delta_cs.PS_k[j] ** 3
            # print("get_coeval_obs_PS() -> ", Delta_cs.PS_k[j], Delta_cs.PS[j])

        P_sv = interpolate.interp1d(
            Delta_cs.PS_k[0 : Delta_cs.PSbins],
            Delta_cs.PS[0 : Delta_cs.PSbins],
            fill_value="extrapolate",
        )
        # ----------------------------------------------------------------------

        # ----------------------------------------------------------------------
        # If a uv-sampling/noise filepath has been passed generate a noisy observed box
        if Inst[i] != -1:
            noisy_box = []
            print(
                "In get_coeval_obs_PS() -> Instrumental info has been passed "
                f"({Inst[i]}) for z = {redshifts[i]:.1f}, simulating a noisy "
                "observed box over simulation box with mean = "
                f"{np.mean(coevals[i].brightness_temp):.1f} and var = "
                f"{np.var(coevals[i].brightness_temp):.1f}"
            )
            # cw pass P_sv after testing that passing Psv=None doesn't change the behaviour
            noise_box = get_obs_coeval(
                Filepath=Inst[i],
                z=redshifts[i],
                Dim=UParams.HII_DIM,
                Len=UParams.BOX_LEN,
                sim_noise=sim_noise,
                Psv=P_sv,
                sim_coeval=coevals[i].brightness_temp,
                omega_m=CParams.OMm,
                hlittle=CParams.hlittle,
            )
            # cw noise_box = get_obs_coeval( Filepath=Inst[i], z=redshifts[i], Dim=UParams.HII_DIM, Len=UParams.BOX_LEN, sim_noise=sim_noise, sim_coeval=None, omega_m = CParams.OMm, hlittle = CParams.hlittle)
            # cw noise_box = np.array(coevals[i].brightness_temp)+noise_box
            if DEBUG == 1:
                print(
                    "In get_coeval_obs_PS() -> sim size and type compared with noise",
                    coevals[i].brightness_temp.shape,
                    coevals[i].brightness_temp.dtype,
                    noise_box.shape,
                    noise_box.dtype,
                )
            # Apply window to force noisy uv-sampled to be a periodic dataset
            # cw conv.nd_windowfunc(noise_box, 0.01)

            if np.all(noise_box == -1):
                print(
                    "In get_coeval_obs_PS() -> Noise has not been calculated "
                    "in get_obs_coeval()"
                )

            # ----------------------------------------------------------------------
            # print("get_coeval_obs_PS() -> shape compare sim and noise ", coevals[i].brightness_temp.dtype, noise_box.dtype )
            # print("get_coeval_obs_PS() -> mean + var of sim before and after averaging. \n \t Before = ", np.mean(coevals[i].brightness_temp), np.var(coevals[i].brightness_temp), "; \t After = ", np.mean(noise_box), np.var(noise_box))
            # ----------------------------------------------------------------------
            print(np.mean(noise_box), np.var(noise_box))
            dTobs = noise_box.ctypes.data_as(c_float_p)
            obs_sim = 1  # This will supress conversion of Tb_obs to  \delta_T*<Tb> which can cause numerical error when uv sampling has already taken care of this step
        else:
            print("get_coeval_obs_PS() -> Analysing clean simulation.")
            if DEBUG == 1:
                hdu = pyfits.PrimaryHDU(coevals[i].brightness_temp)
                hdulist = pyfits.HDUList([hdu])
                filename = "clean_dT_z" + str(redshifts[i]) + ".fits"
                call(["rm", filename])
                hdulist.writeto(filename)
                hdulist.close()
            dTobs = coevals[i].brightness_temp.ctypes.data_as(c_float_p)
            obs_sim = 0
        # ----------------------------------------------------------------------

        # ----------------------------------------------------------------------
        # Construct the 21cm power spectra from the resultant boxes
        output.append(
            Function_21cmPS(
                LightConeFlag,
                obs_sim,
                DIMENSIONAL_T_POWER_SPEC,
                UParams.HII_DIM,
                UParams.BOX_LEN,
                dTobs,
            )
        )

        # Print out the 21cm power spectrum data
        # for j in range(output[i].PSbins):
        # 	print((output[i].PS_k[j]),(output[i].PS[j]),(output[i].PS_error[j]))
        # ----------------------------------------------------------------------
    return output


def main():
    "Main() -> Running basic coeval observation with default settings. For full functionality, use as a module"
    get_coeval_obs_PS()


if __name__ == "__main__":
    main()
