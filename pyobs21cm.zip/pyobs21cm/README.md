Written  by C. Watkinson (catherine.watkinson@gmail.com).
If you make use of this, please reference this repository and 21cmSENSE literature.

This code is designed to be used alongside 21cmMC and 21cmSENSE to simulate
observational boxes.

It currently applies uv sampling (which can exclude wedge corrupted modes if desired)
to co-moving 21cmMC assuming a fixed redshift
when converting from u, v and nu to kx, ky and kz.
Future updates will apply uv sampling to a 21cmMC lightcone on a slice-by-slice basis
along the freq axis (again including wedge effects).

The functions in the main script (simObs_21cmpy) fall into three categories
listed in reverse order to their position in the script):
'WRAPPER' FUNCTIONS - These allow the user to easily calculate various statistics from
                      an 'observed' 21cmMC simulation.
'ACTION' FUNCTIONS - Offering higher-level functionality including the ability
                     to produce uv masks in comoving coords and generate noise realisations.
'HELPER' FUNCTIONS - Used by 'ACTION' functions and rarely needed directly by the user.

There is example_two_param_coeval.py which shows how to use the code. This also has the
option, controlled by CMSENSE_FLAGS_ONLY to simply get flags for use with
Uv_sampling_and_noise/uv_to_k_plus_calc_sense.py (see this folder for info on this program)
that are consistent with your 21cmMC simulation settings.

--------------------------------------------------------------------------------------
'WRAPPER' menu
--------------------------------------------------------------------------------------
PS_from_obs_coeval - power spec as measured from mock observed coeval. Once this has
                     been run once for a given instrument, the mask is saved to file so
                     that subsequent calls are extremely fast.

--------------------------------------------------------------------------------------
'ACTION' menu
--------------------------------------------------------------------------------------
get_obs_coeval - produces a uv-sampled version of passed coeval sim with or without
                 instrumental noise added on top (note this ignores los evolution
                 with the exception the foreground wedge corruption).

get_obs_fft_coeval - as above but in k-space.
                     Can be used to quickly generate multiple noise realisations over a simulation.
                     This can also be used to generate a uv-sampling noise mask
                     in simulation co-ordinates (which can also be acquired in real space
                     by switching off noise sims and not passing a simulation to get_obs_coeval).
                     uv-sampling noise mask contains the noise error or number of samples per cell
                     depending on settings.

--------------------------------------------------------------------------------------
# PyObs21cm Dependencies
--------------------------------------------------------------------------------------
Python 3
21cmMC (https://github.com/BradGreig/Hybrid21CM)
Numpy
Scipy
astropy

Optional for generating new noise sampling files other than those packaged:
21cmSENSE (https://github.com/jpober/21cmSense)
Aipy

--------------------------------------------------------------------------------------
# PyObs21cm Installation notes
--------------------------------------------------------------------------------------
cd to main directory, compile C code:
    make

 All Python code should then work out of the box from the main directory

--------------------------------------------------------------------------------------

# PyObs21cm development notes

Some DEVEL_DESC flags are include in the parts of the code that are relevant

--------------------------------------------------------------------------------------

-----------------------------
# PyObs21cm v1 - In development
-----------------------------
Simple co-moving implementation that includes FG wedge effects but neglects evolution
of signal and uv sampling in frequency direction.

DEVEL_SAMPVAR
At the moment I am approximating the effects of sample variance by treating it as
a noise term, i.e. by adding it's contribution to the instrumental noise sigma which is used to
create random samplings of noise.
This approach is not terribly realistic as there will be correlations in the sv-noise between scales.
i.e. the noise due to sample variance is not i.i.d.
Nonetheless, this remains a useful and cheap way of using MCMC to calculate noise+sv error.

---------------------------------
# PyObs21cm v2 - Future development plans
---------------------------------

DEVEL_LIGHTCONE
I will add a simple co-moving lightcone implementation that applies uv sampling
on a slice-by-slice basis before performing Fourier Transform in freq direction.

To do:
1. check format of 21cmMC lightcone mode
2. integrate uv_to_k_plus_calc_sense calculations inside main code so it maybe
applied on a slice-by-slice basis. This can be easily checked against the
original implementation.
